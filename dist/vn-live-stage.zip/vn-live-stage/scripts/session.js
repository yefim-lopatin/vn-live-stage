import {
  MODULE_ID,
  SOCKET_NAME,
  MAX_HISTORY,
  SPEECH_TIMEOUT_MS,
  clone,
  createCommand,
  createSceneDefinition,
  createInitialState,
  applySceneCommand,
  applyTransientCommand,
  expireSpeaking,
  canUserJoinStage,
  canUserLeaveStage
} from "./core.js";
import { DEFAULT_POLICY, can, normalizePolicy } from "./permissions.js";
import { getSystemAdapter } from "./adapters.js";
import { getScene, readLiveState, saveScene, writeLiveState } from "./storage.js";

export class LiveStageSession {
  constructor() {
    this.state = createInitialState();
    this.listeners = new Set();
    this.cleanup = [];
    this.speaking = false;
    this.speechStarting = false;
    this.speechTimer = null;
  }

  async initialize() {
    this.state = await readLiveState();
    this.state.connectedUsers = game.users.filter((user) => user.active).map((user) => ({ id: user.id, name: user.name }));
    if (game.user.isGM) this.state = expireSpeaking(this.state, 0);
    game.socket.on(SOCKET_NAME, (message, respond) => this._receive(message, respond));
    this._bindHooks();
    if (game.user.isGM) {
      this._startHeartbeatMonitor();
      await this._broadcast();
    } else {
      this._requestSnapshot();
    }
    this._emit();
    return this;
  }

  destroy() {
    for (const stop of this.cleanup.splice(0)) stop();
    clearInterval(this.heartbeatMonitor);
    clearInterval(this.speechTimer);
  }

  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  getState() {
    return clone(this.state);
  }

  async dispatch(input) {
    const command = input?.id ? clone(input) : createCommand(input.type, input.payload, {
      userId: game.user.id,
      revision: this.state.revision
    });
    command.userId = game.user.id;
    if (game.user.isGM) return this._apply(command);
    game.socket.emit(SOCKET_NAME, { kind: "command", userId: game.user.id, command });
    return this.getState();
  }

  async startSpeaking(portraitId = null) {
    if (this.speaking) return this.getState();
    if (!this._speechEnabledForCurrentUser()) throw new Error("Режим сцены не активен");
    this.speaking = true;
    this.speechStarting = true;
    let result;
    try {
      result = await this.dispatch({ type: "speechStart", payload: { portraitId } });
    } catch (error) {
      this.speaking = false;
      throw error;
    } finally {
      this.speechStarting = false;
    }
    if (!this.speaking) {
      await this.dispatch({ type: "speechStop", payload: {} });
      return this.getState();
    }
    this.speechTimer = setInterval(() => {
      if (this.speaking) this.dispatch({ type: "speechHeartbeat", payload: {} }).catch(() => {});
    }, 3000);
    return result;
  }

  async stopSpeaking() {
    if (!this.speaking) return this.getState();
    this.speaking = false;
    clearInterval(this.speechTimer);
    this.speechTimer = null;
    if (this.speechStarting) return this.getState();
    return this.dispatch({ type: "speechStop", payload: {} });
  }

  async prepareStage() {
    return this.dispatch({ type: "prepareStage", payload: {} });
  }

  async publishStage() {
    return this.dispatch({ type: "publishStage", payload: {} });
  }

  async returnToPreparation() {
    return this.dispatch({ type: "returnToPreparation", payload: {} });
  }

  async activateStage() {
    return this.publishStage();
  }

  async deactivateStage() {
    return this.dispatch({ type: "deactivateStage", payload: {} });
  }

  async toggleStage() {
    const phase = this.state.stage?.phase ?? "inactive";
    if (phase === "inactive") return this.prepareStage();
    if (phase === "live") return this.returnToPreparation();
    return this.deactivateStage();
  }

  async newScene(name = "Новая сцена") {
    return this.dispatch({ type: "newScene", payload: { name } });
  }

  async addPortraits(portraits) {
    return this.dispatch({
      type: "addPortraits",
      payload: { portraits: this._refreshPortraits(portraits) }
    });
  }

  async addPlayerAvatars() {
    const adapter = getSystemAdapter();
    const portraits = game.users
      .filter((user) => !user.isGM)
      .map((user) => adapter.getPortrait(user))
      .filter(Boolean);
    if (!portraits.length) throw new Error("У игроков нет назначенных персонажей с аватарами");
    return this.addPortraits(portraits);
  }

  async joinStage() {
    if (!game.settings.get(MODULE_ID, "allowPlayerJoin")) throw new Error("Самостоятельное присоединение отключено ведущим");
    if (!game.user.character) throw new Error("Сначала назначьте пользователю персонажа");
    if (!this.canCurrentUserJoin()) throw new Error("Персонаж уже находится на сцене или сцена не показана");
    return this.dispatch({ type: "joinStage", payload: {} });
  }

  async leaveStage() {
    if (!this.canCurrentUserLeave()) throw new Error("Ваш персонаж не находится на показанной сцене");
    if (this.speaking) await this.stopSpeaking();
    return this.dispatch({ type: "leaveStage", payload: {} });
  }

  canCurrentUserSpeak(portraitId = null) {
    return Boolean(this._portraitFor(game.user.id, portraitId));
  }

  canCurrentUserJoin() {
    return canUserJoinStage(this.state, game.user, {
      enabled: Boolean(game.settings.get(MODULE_ID, "allowPlayerJoin"))
    });
  }

  canCurrentUserLeave() {
    return canUserLeaveStage(this.state, game.user);
  }

  refresh() {
    this._emit();
    return this.getState();
  }

  async saveScene(options = {}) {
    if (!game.user.isGM) return this.dispatch({ type: "saveScene", payload: options });
    await saveScene(this.state, options);
    ui.notifications?.info?.("Сцена сохранена");
    this._emit();
    return this.getState();
  }

  async loadScene(sceneId) {
    return this.dispatch({ type: "loadScene", payload: { sceneId } });
  }

  async undo() {
    return this.dispatch({ type: "undo", payload: {} });
  }

  async redo() {
    return this.dispatch({ type: "redo", payload: {} });
  }

  async _apply(command) {
    try {
      const user = game.users.get(command.userId);
      this._authorize(command, user);
      if (command.type === "prepareStage") {
        if ((this.state.stage?.phase ?? "inactive") !== "inactive") throw new Error("Сцена уже подготовлена или показана");
        this.state.stage = {
          ...this.state.stage,
          phase: "preparing",
          active: false,
          activatedAt: null,
          activatedBy: null
        };
        this.state.speaking = {};
        this._resetLocalSpeaking();
      } else if (command.type === "publishStage") {
        if ((this.state.stage?.phase ?? "inactive") !== "preparing") throw new Error("Сначала подготовьте сцену");
        this.state.stage = {
          ...this.state.stage,
          phase: "live",
          active: true,
          activatedAt: Date.now(),
          activatedBy: command.userId
        };
      } else if (command.type === "returnToPreparation") {
        if ((this.state.stage?.phase ?? "inactive") !== "live") throw new Error("Сцена ещё не показана игрокам");
        this.state.stage = {
          ...this.state.stage,
          phase: "preparing",
          active: false,
          activatedAt: null,
          activatedBy: null
        };
        this.state.speaking = {};
        this._resetLocalSpeaking();
      } else if (command.type === "deactivateStage") {
        this.state.stage = {
          ...this.state.stage,
          phase: "inactive",
          active: false,
          activatedAt: null,
          activatedBy: null
        };
        this.state.speaking = {};
        this.state.overflow = [];
        this.state.stageChecks = [];
        this._resetLocalSpeaking();
      } else if (command.type === "joinStage") {
        const enabled = Boolean(game.settings.get(MODULE_ID, "allowPlayerJoin"));
        if (!enabled) throw new Error("Самостоятельное присоединение отключено ведущим");
        if ((this.state.stage?.phase ?? "inactive") !== "live") throw new Error("Сцена сейчас не показана");
        if (this._portraitFor(command.userId)) throw new Error("Персонаж уже находится на сцене");
        const portrait = getSystemAdapter().getPortrait(user);
        if (!portrait) throw new Error("У игрока нет назначенного персонажа с портретом");
        const joinCommand = {
          ...command,
          type: "addPortrait",
          revision: this.state.revision,
          payload: { ...portrait, side: "left" }
        };
        const result = applySceneCommand(this.state, joinCommand);
        this.state = result.state;
        this.state.history.unshift(result.event);
        this.state.history = this.state.history.slice(0, MAX_HISTORY);
        this.state.redo = [];
      } else if (command.type === "leaveStage") {
        if ((this.state.stage?.phase ?? "inactive") !== "live") throw new Error("Сцена сейчас не показана");
        const result = applySceneCommand(this.state, command);
        this.state = result.state;
        this.state.history.unshift(result.event);
        this.state.history = this.state.history.slice(0, MAX_HISTORY);
        this.state.redo = [];
        this._resetLocalSpeaking();
      } else if (command.type === "recordStageCheckResult") {
        if ((this.state.stage?.phase ?? "inactive") !== "live") throw new Error("Сцена сейчас не показана");
        const message = game.messages?.get(command.payload?.messageId);
        if (!message?.rolls?.length || message.author?.id !== command.userId) {
          throw new Error("Результат проверки не подтверждён");
        }
        const result = applySceneCommand(this.state, command);
        this.state = result.state;
        this.state.history.unshift(result.event);
        this.state.history = this.state.history.slice(0, MAX_HISTORY);
        this.state.redo = [];
      } else if (["speechStart", "speechStop", "speechHeartbeat"].includes(command.type)) {
        const phase = this.state.stage?.phase ?? "inactive";
        const canSpeak = phase === "live" || (phase === "preparing" && user.isGM);
        if (command.type !== "speechStop" && !canSpeak) throw new Error("Режим сцены не активен");
        const portrait = this._portraitFor(command.userId, command.payload?.portraitId);
        if (command.type === "speechStart" && !portrait) throw new Error("У игрока нет персонажа для портрета");
        this.state = applyTransientCommand(this.state, command, { userId: command.userId, portrait });
      } else if (command.type === "saveScene") {
        await saveScene(this.state, command.payload);
      } else if (command.type === "loadScene") {
        const scene = getScene(command.payload.sceneId);
        if (!scene) throw new Error("Сохранённая сцена не найдена");
        this.state.scene = createSceneDefinition(scene);
        this.state.speaking = {};
        this.state.stageChecks = [];
        this.state.revision += 1;
        this.state.history = [];
        this.state.redo = [];
      } else if (command.type === "undo") {
        this._undo();
      } else if (command.type === "redo") {
        this._redo();
      } else {
        if (command.revision !== this.state.revision) throw new Error("Конфликт ревизий: требуется свежий snapshot");
        const result = applySceneCommand(this.state, command);
        this.state = result.state;
        this.state.history.unshift(result.event);
        this.state.history = this.state.history.slice(0, MAX_HISTORY);
        this.state.redo = [];
      }
      this.state.updatedAt = Date.now();
      await writeLiveState(this.state);
      await this._broadcast();
      this._emit();
      return this.getState();
    } catch (error) {
      throw new Error(error.message || "Команда отклонена");
    }
  }

  _authorize(command, user) {
    if (!user) throw new Error("Неизвестный пользователь");
    const policy = normalizePolicy(game.settings.get(MODULE_ID, "permissionPolicy") ?? DEFAULT_POLICY);
    if (["speechStart", "speechStop", "speechHeartbeat"].includes(command.type)) return;
    if (["joinStage", "leaveStage"].includes(command.type) && !user.isGM && user.active !== false) return;
    if (command.type === "recordStageCheckResult" && user.active !== false) return;
    if (["prepareStage", "publishStage", "returnToPreparation", "deactivateStage"].includes(command.type) && user.isGM) return;
    if (command.type === "createRequest" && user.active !== false) return;
    if (["resolveRequest"].includes(command.type) && can(user, "requestReview", policy)) return;
    if (["saveScene"].includes(command.type) && can(user, "saveScene", policy)) return;
    if (["undo", "redo"].includes(command.type) && can(user, "undo", policy)) return;
    if (["loadScene"].includes(command.type) && can(user, "sceneControl", policy)) return;
    if (["newScene", "addPortrait", "addPortraits", "removePortrait", "movePortrait", "updatePortrait", "setSceneDetails", "setLocation", "setBackground", "setBackgroundVisibility", "setEnvironment", "createStageChecks"].includes(command.type) && can(user, "sceneControl", policy)) return;
    throw new Error("Недостаточно прав для этой команды");
  }

  _portraitFor(userId, requestedPortraitId = null) {
    const active = this.state.speaking[userId];
    const existing = active && [...this.state.scene.portraits, ...this.state.overflow].find((item) => item.id === active.portraitId);
    if (existing) return existing;
    const user = game.users.get(userId);
    if (user?.isGM) {
      return this.state.scene.portraits.find((portrait) => portrait.id === requestedPortraitId) ?? null;
    }
    const profileId = `user-${userId}`;
    const known = [...this.state.scene.portraits, ...this.state.overflow].find((item) => item.profileId === profileId);
    return known ?? null;
  }

  _refreshPortraits(portraits = []) {
    const adapter = getSystemAdapter();
    return portraits.map((portrait) => {
      if (!portrait?.sourceUserId) return clone(portrait);
      const current = adapter.getPortrait(game.users.get(portrait.sourceUserId));
      if (!current) return clone(portrait);
      return {
        ...clone(portrait),
        ...current,
        id: portrait.id ?? current.id,
        profileId: portrait.profileId ?? current.profileId,
        side: ["left", "right"].includes(portrait.side) ? portrait.side : "left",
        flipped: Boolean(portrait.flipped)
      };
    });
  }

  _resetLocalSpeaking() {
    this.speaking = false;
    this.speechStarting = false;
    clearInterval(this.speechTimer);
    this.speechTimer = null;
  }

  _speechEnabledForCurrentUser() {
    const phase = this.state.stage?.phase ?? "inactive";
    return phase === "live" || (phase === "preparing" && game.user.isGM);
  }

  _undo() {
    const event = this.state.history.shift();
    if (!event) throw new Error("Нет действий для отмены");
    this.state.redo.unshift(event);
    this.state.scene = clone(event.beforeState?.scene ?? event.before);
    if (event.beforeState) {
      this.state.requests = clone(event.beforeState.requests);
      this.state.overflow = clone(event.beforeState.overflow);
      this.state.stageChecks = clone(event.beforeState.stageChecks ?? []);
    }
    this.state.revision += 1;
  }

  _redo() {
    const event = this.state.redo.shift();
    if (!event) throw new Error("Нет действий для повтора");
    this.state.history.unshift(event);
    this.state.scene = clone(event.afterState?.scene ?? event.after);
    if (event.afterState) {
      this.state.requests = clone(event.afterState.requests);
      this.state.overflow = clone(event.afterState.overflow);
      this.state.stageChecks = clone(event.afterState.stageChecks ?? []);
    }
    this.state.revision += 1;
  }

  async _receive(message, respond) {
    if (!message?.kind) return;
    if (["snapshot", "stage-show", "stage-state"].includes(message.kind)) {
      const isTarget = !message.targetUserId || message.targetUserId === game.user.id;
      if (!game.user.isGM && isTarget && message.state) {
        this.state = clone(message.state);
        if (!this._speechEnabledForCurrentUser() || !this.state.speaking?.[game.user.id]) this._resetLocalSpeaking();
        this._emit();
      }
      return;
    }
    if (message.kind === "command-error") {
      const isTarget = message.targetUserId === game.user.id;
      if (!game.user.isGM && isTarget) {
        if (["speechStart", "speechHeartbeat"].includes(message.commandType)) this._resetLocalSpeaking();
        ui.notifications?.error?.(message.error ?? "Команда отклонена");
      }
      return;
    }
    if (message.kind === "sync") {
      if (game.user.isGM) await this._broadcast({ targetUserId: message.userId });
      return;
    }
    if (message.kind !== "command" || !game.user.isGM) return;
    try {
      const state = await this._apply({ ...message.command, userId: message.userId, payload: clone(message.command?.payload) });
      respond?.({ ok: true, state });
    } catch (error) {
      respond?.({ ok: false, error: error.message, state: this.getState() });
      game.socket.emit(SOCKET_NAME, {
        kind: "command-error",
        targetUserId: message.userId,
        commandType: message.command?.type,
        error: error.message || "Команда отклонена"
      });
    }
  }

  _requestSnapshot() {
    game.socket.emit(SOCKET_NAME, { kind: "sync", userId: game.user.id });
  }

  async _syncFromStorage() {
    this.state = await readLiveState();
    if (!this._speechEnabledForCurrentUser() || !this.state.speaking?.[game.user.id]) this._resetLocalSpeaking();
  }

  async _broadcast({ targetUserId = null } = {}) {
    const state = this.getState();
    game.socket.emit(SOCKET_NAME, {
      kind: state.stage?.phase === "live" ? "stage-show" : "stage-state",
      targetUserId,
      state
    });
  }

  _startHeartbeatMonitor() {
    this.heartbeatMonitor = setInterval(async () => {
      const next = expireSpeaking(this.state, SPEECH_TIMEOUT_MS);
      if (JSON.stringify(next.speaking) !== JSON.stringify(this.state.speaking)) {
        this.state = next;
        await writeLiveState(this.state);
        await this._broadcast();
        this._emit();
      }
    }, 3000);
  }

  _bindHooks() {
    const onUser = () => {
      this.state.connectedUsers = game.users.filter((user) => user.active).map((user) => ({ id: user.id, name: user.name }));
      this._broadcast().catch(() => {});
      this._emit();
    };
    const hookId = Hooks.on("updateUser", onUser);
    this.cleanup.push(() => Hooks.off("updateUser", hookId));
    const onSetting = async (setting) => {
      if (game.user.isGM || setting?.key !== `${MODULE_ID}.liveState`) return;
      await this._syncFromStorage();
      this._emit();
    };
    const settingHookId = Hooks.on("updateSetting", onSetting);
    this.cleanup.push(() => Hooks.off("updateSetting", settingHookId));
    const onBlur = () => this.speaking && this.stopSpeaking().catch(() => {});
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onBlur);
    window.addEventListener("pagehide", onBlur);
    this.cleanup.push(() => window.removeEventListener("blur", onBlur));
    this.cleanup.push(() => document.removeEventListener("visibilitychange", onBlur));
    this.cleanup.push(() => window.removeEventListener("pagehide", onBlur));
  }

  _emit() {
    const snapshot = this.getState();
    for (const listener of this.listeners) listener(snapshot);
  }
}
